import { useState, useCallback } from "react";
//useCallback은 주로 랜더링으 최적화 할때 사용됨
import { MdAddCircleOutline } from "react-icons/md";

import "./TodoInsert.scss";

const TodoInsert = ({ onInsert }) => {
  const [value, setValue] = useState(""); // 인풋 초기 내용 비우기
  const onChange = useCallback((e) => {
    //인풋에 추가로 넣어줄 함수 onChange 작성
    setValue(e.target.value); //입력한 값이 해당요소에 계속 추가될수 있도록
  }, []); //내용이 바뀌어써을때 함수가 실행되도록

  const onSubmit = useCallback(
    (e) => {
      onInsert(value);
      setValue("");

      //submit이벤트는 브라우저에서 새로고침을 발생함 이를 방지하기 위해 이 함수를 호출

      e.preventDefault();
    },
    [onInsert, value]
  ); //내용이 변경되었을떄만 함수가 실행되도록
  return (
    <form className="TodoInsert" onSubmit={onSubmit}>
      {" "}
      <input
        placeholder="할 일을 입력하세요"
        value={value}
        onChange={onChange}
      />
      <button type="submit">
        <MdAddCircleOutline />
      </button>
    </form>
  );
};
export default TodoInsert;
