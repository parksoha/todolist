import {
  MdCheckBoxOutlineBlank, //리액트 아이콘 명
  MdCheckBox,
  MdRemoveCircleOutline,
} from "react-icons/md";
import cn from "classnames"; //classnames 라이브러리를 cn으로 이름 지어 가져옴.
import "./TodoListItem.scss";

const TodoListItem = ({ todo, onRemove, onToggle }) => {
  //TodoListItem 함수 컴포넌트. 파라미터로 todo 바인딩.(인풋의 텍스트입력창과 체크박스 )
  const { id, text, checked } = todo;

  return (
    <div className="TodoListItem">
      {" "}
      {/* 스타일연결 */}
      <div className={cn("checkbox", { checked })} onClick={() => onToggle(id)}>
        {" "}
        {checked ? <MdCheckBox /> : <MdCheckBoxOutlineBlank />}
        <div className="text">{text}</div>
      </div>
      <div className="remove" onClick={() => onRemove(id)}>
        <MdRemoveCircleOutline /> {/* 삭제버튼 */}
      </div>
    </div>
  );
};

export default TodoListItem;
